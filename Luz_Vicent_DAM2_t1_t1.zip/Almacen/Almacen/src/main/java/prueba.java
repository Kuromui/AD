import database.DBConnection;

import java.sql.Connection;
import java.sql.SQLException;

/*public class prueba {
    public static void main(String[] args) throws SQLException {
        DBConnection dbConnection = new DBConnection();
        Connection connection = dbConnection.getConnection();
        if (connection != null) {
            System.out.println("La conexión a la base de datos es exitosa.");
        } else {
            System.out.println("La conexión a la base de datos falló.");
        }
    }
}*/

